-- Hollowmere 2 initial Supabase schema
-- Run in the SQL Editor of a NEW Supabase project.
-- Never expose the service_role key in a browser client.

create extension if not exists pgcrypto;

create table if not exists public.player_profiles (
  user_id uuid primary key references auth.users(id) on delete cascade,
  display_name text not null default 'Adventurer' check (char_length(display_name) between 1 and 20),
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create table if not exists public.player_saves (
  user_id uuid primary key references auth.users(id) on delete cascade,
  schema_version integer not null default 1,
  character_name text not null default 'Adventurer',
  world_id text not null default 'hollowmere-1',
  location_id text not null default 'village',
  state jsonb not null default '{}'::jsonb,
  revision bigint not null default 1,
  saved_at timestamptz not null default now(),
  constraint player_saves_state_object check (jsonb_typeof(state) = 'object')
);

create table if not exists public.world_presence (
  user_id uuid primary key references auth.users(id) on delete cascade,
  world_id text not null default 'hollowmere-1',
  character_name text not null default 'Adventurer',
  location_id text not null default 'village',
  x double precision not null default 0,
  y double precision not null default 0,
  combat_level integer not null default 3 check (combat_level between 1 and 126),
  updated_at timestamptz not null default now()
);

create index if not exists world_presence_world_location_idx
  on public.world_presence (world_id, location_id, updated_at desc);

create table if not exists public.world_chat (
  id bigint generated always as identity primary key,
  user_id uuid not null references auth.users(id) on delete cascade,
  world_id text not null default 'hollowmere-1',
  channel text not null default 'public' check (channel in ('public','trade','help','clan')),
  character_name text not null,
  message text not null check (char_length(message) between 1 and 240),
  created_at timestamptz not null default now()
);

create index if not exists world_chat_world_created_idx
  on public.world_chat (world_id, created_at desc);

create table if not exists public.world_events (
  id uuid primary key default gen_random_uuid(),
  world_id text not null default 'hollowmere-1',
  event_type text not null,
  payload jsonb not null default '{}'::jsonb,
  created_by uuid references auth.users(id) on delete set null,
  created_at timestamptz not null default now(),
  expires_at timestamptz
);

-- Profile creation for every new authenticated account.
create or replace function public.handle_new_hollowmere_user()
returns trigger
language plpgsql
security definer
set search_path = ''
as $$
begin
  insert into public.player_profiles (user_id, display_name)
  values (new.id, coalesce(nullif(new.raw_user_meta_data ->> 'display_name',''), 'Adventurer'))
  on conflict (user_id) do nothing;
  return new;
end;
$$;

drop trigger if exists on_auth_user_created_hollowmere on auth.users;
create trigger on_auth_user_created_hollowmere
after insert on auth.users
for each row execute procedure public.handle_new_hollowmere_user();

alter table public.player_profiles enable row level security;
alter table public.player_saves enable row level security;
alter table public.world_presence enable row level security;
alter table public.world_chat enable row level security;
alter table public.world_events enable row level security;

-- A player can only read/write their own profile and save.
drop policy if exists "profile read own" on public.player_profiles;
create policy "profile read own" on public.player_profiles for select to authenticated using (auth.uid() = user_id);
drop policy if exists "profile update own" on public.player_profiles;
create policy "profile update own" on public.player_profiles for update to authenticated using (auth.uid() = user_id) with check (auth.uid() = user_id);

drop policy if exists "save read own" on public.player_saves;
create policy "save read own" on public.player_saves for select to authenticated using (auth.uid() = user_id);
drop policy if exists "save insert own" on public.player_saves;
create policy "save insert own" on public.player_saves for insert to authenticated with check (auth.uid() = user_id);
drop policy if exists "save update own" on public.player_saves;
create policy "save update own" on public.player_saves for update to authenticated using (auth.uid() = user_id) with check (auth.uid() = user_id);

-- Presence and public chat can be read by signed-in players. A player may
-- publish only their own presence and chat identity. Rate limiting and
-- server-side validation should be added before a public production launch.
drop policy if exists "presence read authenticated" on public.world_presence;
create policy "presence read authenticated" on public.world_presence for select to authenticated using (true);
drop policy if exists "presence insert own" on public.world_presence;
create policy "presence insert own" on public.world_presence for insert to authenticated with check (auth.uid() = user_id);
drop policy if exists "presence update own" on public.world_presence;
create policy "presence update own" on public.world_presence for update to authenticated using (auth.uid() = user_id) with check (auth.uid() = user_id);
drop policy if exists "presence delete own" on public.world_presence;
create policy "presence delete own" on public.world_presence for delete to authenticated using (auth.uid() = user_id);

drop policy if exists "chat read authenticated" on public.world_chat;
create policy "chat read authenticated" on public.world_chat for select to authenticated using (true);
drop policy if exists "chat insert own" on public.world_chat;
create policy "chat insert own" on public.world_chat for insert to authenticated with check (auth.uid() = user_id);

-- Events are visible to authenticated players; only trusted server/service
-- code should create or modify them. No client write policy is provided.
drop policy if exists "events read authenticated" on public.world_events;
create policy "events read authenticated" on public.world_events for select to authenticated using (true);

-- Enable Realtime publication for live world presence and chat.
do $$ begin
  alter publication supabase_realtime add table public.world_presence;
exception when duplicate_object then null;
when undefined_object then null;
end $$;
do $$ begin
  alter publication supabase_realtime add table public.world_chat;
exception when duplicate_object then null;
when undefined_object then null;
end $$;
