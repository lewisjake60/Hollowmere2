# Hollowmere 2

Hollowmere 2 is a browser-game fork of Hollowmere Enhanced. It retains the existing world map, towns, NPCs, quests, skills, inventory, combat, gathering, crafting, and WebGL 3D renderer. It uses a separate browser save namespace and imports an existing Hollowmere v1 local save on first launch.

## Play

- The game must be opened as a web page in Safari/Chrome, not viewed as plain text or inside a file-preview pane.
- For iPhone, deploy `Hollowmere2.html` to an HTTPS static host, then open that URL in Safari. Rotate to landscape for the intended layout.
- The splash screen now has a timeout fallback so a WebGL setup issue cannot leave the game permanently covered by the loading screen. If WebGL is unavailable, the game's built-in 2D fallback is used.

## Supabase starter

`supabase/schema.sql` creates initial account-profile, player-save, presence, chat, and world-event tables with row-level security. It is not yet connected to a live Supabase project. Supabase Auth, cloud save synchronization, server-authoritative multiplayer, and public hosting still need to be configured.

Never put a Supabase service-role key in browser code. Use the project URL and anon/public key for client-side setup, with security enforced by RLS and server-side functions.
